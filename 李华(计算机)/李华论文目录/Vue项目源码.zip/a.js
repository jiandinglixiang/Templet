[
  { "pathname": "WILDCARD:/publish" },
  { "pathname": "WILDCARD:/user" },
  { "pathname": "WILDCARD:/search" },
  { "pathname": "WILDCARD:/commodity/details" },
  { "pathname": "WILDCARD:/info/copyright/list" },
  { "pathname": "WILDCARD:/info/sellsy/list" },
  { "pathname": "WILDCARD:/info/download/list" },
  { "pathname": "WILDCARD:/info/amend" },
  { "pathname": "WILDCARD:/info/bank" },
  { "pathname": "WILDCARD:/publish/leaveAMessage" },
  { "pathname": "WILDCARD:/login" }
]
